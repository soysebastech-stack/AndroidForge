package com.mimovilapps.ios27launcher

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        setContent {
            val prefs = getSharedPreferences("liquid_glass", MODE_PRIVATE)
            LauncherScreen(
                onLaunch = { launchPackage(it) },
                loadApps = { installedApps() },
                loadPreference = { key, fallback -> prefs.getInt(key, fallback) },
                savePreference = { key, value -> prefs.edit().putInt(key, value).apply() },
                initialWallpaper = prefs.getString("customWallpaperUri", null)?.let { saved ->
                    try { contentResolver.openInputStream(Uri.parse(saved))?.use { BitmapFactory.decodeStream(it) } }
                    catch (_: Exception) { null }
                },
                onPickWallpaper = { uri ->
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Exception) { }
                    try { contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }
                    catch (_: Exception) { null }
                },
                saveWallpaperUri = { uri ->
                    if (uri == null) prefs.edit().remove("customWallpaperUri").apply()
                    else prefs.edit().putString("customWallpaperUri", uri.toString()).apply()
                }
            )
        }
    }

    private fun launchPackage(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
    }

    private fun installedApps(): List<LauncherApp> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { info ->
                val name = info.loadLabel(packageManager)?.toString() ?: return@mapNotNull null
                LauncherApp(name, info.activityInfo.packageName, drawableToBitmap(info.loadIcon(packageManager)))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.name.lowercase(Locale.getDefault()) }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable) return drawable.bitmap
        val bitmap = Bitmap.createBitmap(144, 144, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}

data class LauncherApp(val name: String, val packageName: String, val icon: Bitmap)

private val wallpapers = listOf(
    listOf(Color(0xFF101B45), Color(0xFF5B79B8), Color(0xFFB5D9F5)),
    listOf(Color(0xFF321C65), Color(0xFFB66DCC), Color(0xFFF3B9D7)),
    listOf(Color(0xFF062E37), Color(0xFF28A6A0), Color(0xFFB9E7D8)),
    listOf(Color(0xFF5A1D27), Color(0xFFE17A76), Color(0xFFFFD6B0)),
    listOf(Color(0xFF171923), Color(0xFF536078), Color(0xFFC5D0E1))
)

@Composable
fun LauncherScreen(
    onLaunch: (String) -> Unit,
    loadApps: () -> List<LauncherApp>,
    loadPreference: (String, Int) -> Int,
    savePreference: (String, Int) -> Unit,
    onPickWallpaper: (Uri) -> Bitmap?,
    initialWallpaper: Bitmap?,
    saveWallpaperUri: (Uri?) -> Unit
) {
    val apps = remember { loadApps() }
    var search by remember { mutableStateOf("") }
    var showLibrary by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var columns by remember { mutableIntStateOf(loadPreference("columns", 4).coerceIn(3, 6)) }
    var iconSize by remember { mutableIntStateOf(loadPreference("iconSize", 58).coerceIn(42, 78)) }
    var glass by remember { mutableIntStateOf(loadPreference("glass", 24).coerceIn(8, 42)) }
    var wallpaperIndex by remember { mutableIntStateOf(loadPreference("wallpaper", 0).coerceIn(0, wallpapers.lastIndex)) }
    var customWallpaper by remember { mutableStateOf(initialWallpaper) }
    var hideLabels by remember { mutableStateOf(loadPreference("hideLabels", 0) == 1) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            customWallpaper = onPickWallpaper(uri)
            if (customWallpaper != null) saveWallpaperUri(uri)
        }
    }
    val time = remember { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) }
    val date = remember { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()) }
    val backgroundBrush = Brush.linearGradient(wallpapers[wallpaperIndex])
    val visibleApps = apps.filter { it.name.contains(search, ignoreCase = true) }

    Box(Modifier.fillMaxSize()) {
        if (customWallpaper != null) {
            Image(customWallpaper!!.asImageBitmap(), null, modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(.18f)))
        } else Box(Modifier.fillMaxSize().background(backgroundBrush))
        Box(Modifier.align(Alignment.TopEnd).size(260.dp).offset(x = 90.dp, y = 90.dp).background(Color.White.copy(.12f), CircleShape))
        Box(Modifier.align(Alignment.BottomStart).size(220.dp).offset(x = (-80).dp, y = 50.dp).background(Color(0xFFB8D9FF).copy(.13f), CircleShape))

        if (showSettings) {
            SettingsScreen(
                columns = columns, iconSize = iconSize, glass = glass, wallpaperIndex = wallpaperIndex,
                hideLabels = hideLabels,
                onBack = { showSettings = false },
                onColumns = { columns = it; savePreference("columns", it) },
                onIconSize = { iconSize = it; savePreference("iconSize", it) },
                onGlass = { glass = it; savePreference("glass", it) },
                onWallpaper = { wallpaperIndex = it; customWallpaper = null; savePreference("wallpaper", it); saveWallpaperUri(null) },
                onCustomWallpaper = { picker.launch(arrayOf("image/*")) },
                onHideLabels = { hideLabels = it; savePreference("hideLabels", if (it) 1 else 0) }
            )
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(24.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(time, color = Color.White, fontSize = 58.sp, fontWeight = FontWeight.Light)
                        Text(date.replaceFirstChar { it.uppercase() }, color = Color.White.copy(.88f), fontSize = 15.sp)
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, "Ajustes", tint = Color.White, modifier = Modifier.size(27.dp))
                    }
                }
                Spacer(Modifier.height(22.dp))
                GlassPanel(alpha = glass / 100f) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Widgets, null, tint = Color.White, modifier = Modifier.size(25.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Launcher iOS 27", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Tu Android, con una nueva apariencia", color = Color.White.copy(.72f), fontSize = 12.sp)
                        }
                        Text("27", color = Color.White.copy(.9f), fontSize = 22.sp, fontWeight = FontWeight.Light)
                    }
                }
                Spacer(Modifier.height(22.dp))
                if (showLibrary) {
                    OutlinedTextField(
                        value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Buscar aplicaciones…", color = Color.White.copy(.65f)) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = Color.White) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color.White.copy(.55f), unfocusedBorderColor = Color.White.copy(.3f), cursorColor = Color.White),
                        shape = RoundedCornerShape(22.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                } else {
                    Text("APLICACIONES", color = Color.White.copy(.78f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(12.dp))
                }
                val gridApps = if (showLibrary) visibleApps else visibleApps.take(columns * 3)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns), modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(17.dp), horizontalArrangement = Arrangement.spacedBy(7.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(gridApps, key = { it.packageName }) { app ->
                        AppIcon(app, iconSize, hideLabels) { onLaunch(app.packageName) }
                    }
                }
                GlassPanel(alpha = glass / 100f, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        apps.take(4).forEach { app -> SmallDockIcon(app) { onLaunch(app.packageName) } }
                        Box(Modifier.size(47.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(.2f)).clickable {
                            showLibrary = !showLibrary; search = ""
                        }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Search, "Biblioteca", tint = Color.White, modifier = Modifier.size(25.dp))
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(if (showLibrary) "Biblioteca · ${apps.size} aplicaciones" else "Launcher iOS 27 · ${apps.size} aplicaciones", color = Color.White.copy(.68f), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun SettingsScreen(
    columns: Int, iconSize: Int, glass: Int, wallpaperIndex: Int, hideLabels: Boolean,
    onBack: () -> Unit, onColumns: (Int) -> Unit, onIconSize: (Int) -> Unit,
    onGlass: (Int) -> Unit, onWallpaper: (Int) -> Unit, onCustomWallpaper: () -> Unit,
    onHideLabels: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 16.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White) }
            Text("Ajustes", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
        }
        androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(15.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                SettingsCard("Fondos de pantalla") {
                    Text("Fondos originales inspirados en la estética iOS 27", color = Color.White.copy(.78f), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.padding(top = 12.dp)) {
                        wallpapers.forEachIndexed { index, colors ->
                            Box(Modifier.weight(1f).height(75.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(colors))
                                .border(if (wallpaperIndex == index) 2.dp else 0.dp, Color.White, RoundedCornerShape(15.dp))
                                .clickable { onWallpaper(index) })
                        }
                    }
                    OutlinedButton(onClick = onCustomWallpaper, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                        Icon(Icons.Default.ImageIcon, null); Spacer(Modifier.width(8.dp)); Text("Elegir una foto de mi galería")
                    }
                }
            }
            item {
                SettingsCard("Tamaño de los iconos · ${iconSize} dp") {
                    Slider(value = iconSize.toFloat(), onValueChange = { onIconSize(it.toInt()) }, valueRange = 42f..78f)
                    Text("Ajusta el tamaño de los iconos de la pantalla principal", color = Color.White.copy(.72f), fontSize = 12.sp)
                }
            }
            item {
                SettingsCard("Cuadrícula · ${columns} columnas") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (3..6).forEach { count ->
                            FilterChip(selected = columns == count, onClick = { onColumns(count) }, label = { Text("$count") })
                        }
                    }
                    Text("Elige cuántas aplicaciones aparecen en cada fila", color = Color.White.copy(.72f), fontSize = 12.sp)
                }
            }
            item {
                SettingsCard("Efecto Liquid Glass · ${glass}%") {
                    Slider(value = glass.toFloat(), onValueChange = { onGlass(it.toInt()) }, valueRange = 8f..42f)
                    Text("Controla la intensidad de transparencia del dock y los paneles", color = Color.White.copy(.72f), fontSize = 12.sp)
                }
            }
            item {
                SettingsCard("Etiquetas de aplicaciones") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Ocultar nombres de aplicaciones", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = hideLabels, onCheckedChange = onHideLabels)
                    }
                }
            }
            item {
                SettingsCard("Privacidad y seguridad") {
                    Text("Launcher iOS 27 no incluye anuncios, analítica ni cuentas de usuario en esta versión. No solicita permisos de ubicación, contactos, llamadas, SMS ni almacenamiento general.", color = Color.White.copy(.82f), fontSize = 12.sp)
                    Text("La lista de aplicaciones se consulta en el dispositivo para mostrar accesos directos. Las fotos de fondo se eligen mediante el selector del sistema y permanecen en el dispositivo; no se envían a servidores.", color = Color.White.copy(.82f), fontSize = 12.sp)
                    Text("Puedes cambiar el fondo o desinstalar la aplicación cuando quieras. La política de privacidad pública deberá enlazarse en Google Play antes del envío.", color = Color.White.copy(.82f), fontSize = 12.sp)
                }
            }
            item {
                SettingsCard("Acerca de Launcher iOS 27") {
                    Text("Launcher iOS 27 · Liquid Glass", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text("Versión 0.3.0", color = Color.White.copy(.72f), fontSize = 12.sp)
                    Text("Desarrollador: soysebas.tech", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Launcher independiente para Android. Inspirado en una estética de cristal fluido.", color = Color.White.copy(.72f), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    GlassPanel(Modifier.fillMaxWidth(), alpha = .27f) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
fun GlassPanel(modifier: Modifier = Modifier, alpha: Float = .24f, content: @Composable () -> Unit) {
    val a = alpha.coerceIn(.08f, .42f)
    Box(modifier.clip(RoundedCornerShape(28.dp)).background(
        Brush.linearGradient(listOf(Color.White.copy(a + .12f), Color.White.copy(a * .38f), Color.White.copy(a * .72f)))
    ).border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.55f), Color.White.copy(.12f))), RoundedCornerShape(28.dp))) { content() }
}

@Composable
fun AppIcon(app: LauncherApp, iconSize: Int, hideLabels: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(vertical = 3.dp)) {
        Image(app.icon.asImageBitmap(), contentDescription = app.name, modifier = Modifier.size(iconSize.dp).clip(RoundedCornerShape((iconSize * .29f).dp)))
        if (!hideLabels) {
            Spacer(Modifier.height(5.dp))
            Text(app.name, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun SmallDockIcon(app: LauncherApp, onClick: () -> Unit) {
    Image(app.icon.asImageBitmap(), contentDescription = app.name, modifier = Modifier.size(45.dp).clip(RoundedCornerShape(15.dp)).clickable(onClick = onClick))
}
