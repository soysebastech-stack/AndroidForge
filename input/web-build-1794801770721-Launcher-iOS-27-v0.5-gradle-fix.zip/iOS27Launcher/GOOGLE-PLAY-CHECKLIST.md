# Lista de preparación para Google Play — Launcher iOS 27

## Configuración técnica de esta iteración
- Application ID: `com.mimovilapps.ios27launcher`
- Nombre visible: `Launcher iOS 27`
- Marca de interfaz: `Liquid Glass`
- Desarrollador mostrado: `soysebas.tech`
- `minSdk`: 26 (Android 8.0)
- `targetSdk` / `compileSdk`: 36 (Android 16)
- Sin permisos de ubicación, contactos, llamadas, SMS, cámara, micrófono o almacenamiento general.
- Sin anuncios ni SDK de analítica en las dependencias actuales.
- La consulta de apps se limita a actividades que responden a `MAIN` + `LAUNCHER` mediante `<queries>`; no se declara `QUERY_ALL_PACKAGES`.
- El selector de documentos del sistema se usa para el fondo personal; se conserva permiso de lectura para ese URI elegido.

## Requisitos que deben completarse en Play Console
1. Crear la ficha de la aplicación y confirmar el nombre público disponible.
2. Subir un Android App Bundle (AAB) firmado con una clave de carga protegida.
3. Publicar la política de privacidad en una URL pública y estable y añadir la misma URL en Play Console. El archivo `PRIVACY-POLICY.html` es el borrador de esa página; añadir un medio de contacto real antes de publicarla.
4. Completar Seguridad de los datos basándose en el artefacto final y sus dependencias. Para la configuración actual, confirmar que no se recopilan ni comparten datos; no marcarlo automáticamente sin revisar el AAB final.
5. Declarar correctamente si contiene anuncios (la versión actual no integra anuncios).
6. Completar clasificación de contenido, público objetivo y demás declaraciones de Contenido de la aplicación.
7. Preparar icono de ficha de 512×512, gráfico de funciones de 1024×500, capturas reales de la app en teléfonos/tabletas compatibles y descripción de la tienda.
8. Probar el launcher en Android 8, Android 10/11, Android 13, Android 15/16; probar selección como app Inicio predeterminada, retorno desde apps, rotación, fondos persistentes, memoria y accesibilidad.
9. Ejecutar pruebas de calidad y revisión de políticas en Play Console; resolver todos los errores y advertencias antes del lanzamiento.
10. Configurar correo/contacto de soporte del desarrollador en la ficha. No se ha inventado ningún correo en este proyecto.

## Importante
Cumplir con el target API 36 es necesario para nuevas apps según el calendario vigente, pero no garantiza aprobación. Google Play evalúa el artefacto, la ficha, declaraciones, privacidad, contenido, calidad y cuenta del desarrollador. La aprobación solo la puede confirmar Google Play.
