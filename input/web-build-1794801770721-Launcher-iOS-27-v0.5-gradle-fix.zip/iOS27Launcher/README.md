# Launcher iOS 27 — Liquid Glass

**Desarrollador mostrado:** soysebas.tech  
**Versión de desarrollo:** 0.3.1 (ajuste de compilación)  
**Application ID:** `com.mimovilapps.ios27launcher`

## Funciones implementadas en el código
- Actividad HOME/launcher que Android puede ofrecer como pantalla de inicio predeterminada.
- Consulta y apertura de aplicaciones con categoría `LAUNCHER`.
- Biblioteca de aplicaciones y búsqueda.
- Dock visual Liquid Glass.
- Ajuste persistente de cuadrícula (3–6 columnas), tamaño de iconos y transparencia.
- Mostrar/ocultar etiquetas con preferencia persistente.
- Fondos abstractos originales incluidos.
- Selector del sistema para elegir una imagen propia; se guarda el URI con permiso persistente para mantener el fondo tras reiniciar la app.
- Ajustes con sección de privacidad/seguridad y datos del desarrollador.
- Icono adaptativo Android con el arte suministrado por el usuario y la leyenda LIQUID GLASS.
- Sin permisos sensibles ni SDK de anuncios/analítica en las dependencias actuales.

## Compatibilidad
- Android 8.0 (API 26) como mínimo.
- Compilación dirigida a Android 16 (API 36), conforme al requisito de nuevas apps de Google Play vigente desde el 31 de agosto de 2026.
- La apariencia y el rendimiento de desenfoques/transparencias pueden variar por fabricante y hardware.

## Compilar
Requisitos: Android Studio reciente, JDK 17 y Android SDK Platform 36. Abrir la carpeta `iOS27Launcher` en Android Studio y sincronizar Gradle. Esta revisión fija Android Gradle Plugin 8.7.3, compatible con Gradle 8.9, que es la versión que reportó AndroidForge en el registro recibido. Se conserva compileSdk/targetSdk 36; AGP 8.7.3 puede mostrar una advertencia porque API 36 es posterior a su rango oficialmente probado.

- APK de pruebas: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- AAB: **Build > Generate Signed Bundle / APK > Android App Bundle**. Para Google Play se necesita firmar el AAB con una clave de carga propia y conservarla de forma segura.

El entorno de trabajo donde se preparó este paquete no tiene Android SDK ni Gradle instalados y no tiene acceso de red para descargarlos; por eso esta entrega es código fuente preparado, no un APK/AAB compilado ni probado. La carpeta `.github/workflows` contiene una compilación automatizada para ejecutar en GitHub Actions una vez subido el proyecto a un repositorio.

## Documentos de publicación
- `PRIVACY-POLICY.html`: borrador de política de privacidad; publicar en una URL pública y añadir contacto real antes de enviar a Play.
- `GOOGLE-PLAY-CHECKLIST.md`: pasos técnicos y de Play Console.

La aprobación de Google Play no se puede garantizar; depende de la revisión de Google y de completar las declaraciones y activos de la ficha.

La app es un launcher independiente para Android y no está afiliada ni respaldada por Apple.


## Nota de esta revisión 0.5
- Se corrigió la incompatibilidad detectada: AndroidForge ejecutaba Gradle 8.9, mientras Android Gradle Plugin 8.10.1 exigía Gradle 8.11.1.
- Se cambió Android Gradle Plugin a 8.7.3 para que pueda ejecutarse con Gradle 8.9.
- Se añadió `gradle/wrapper/gradle-wrapper.properties` con Gradle 8.9 para entornos que sí usan el wrapper.
- Esta corrección aborda el error de versión reportado; no constituye una compilación verificada. Si aparece otro error, habrá que revisar el siguiente registro.
