# Estado de compilación — revisión 0.5

Corrección aplicada a partir del registro de AndroidForge del 15 de noviembre de 2026:

- Entorno: Gradle 8.9.
- Error original: Android Gradle Plugin 8.10.1 exigía Gradle 8.11.1 como mínimo.
- Cambio: Android Gradle Plugin 8.7.3, compatible con Gradle 8.9.
- Se añadió gradle/wrapper/gradle-wrapper.properties.
- Se conserva compileSdk 36 y targetSdk 36; AGP 8.7.3 podría advertir que API 36 está fuera de su rango oficialmente probado.

El paquete es código fuente corregido, no un APK probado. La compilación debe ejecutarse en AndroidForge para confirmar el resultado.
