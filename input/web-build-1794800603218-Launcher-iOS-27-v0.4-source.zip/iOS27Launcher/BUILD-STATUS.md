# Estado de compilación y validación

- [x] Configuración de `compileSdk` 36 y `targetSdk` 36.
- [x] `minSdk` 26 (Android 8.0).
- [x] Manifiesto XML y recursos XML parseados correctamente.
- [x] Revisión estática de permisos: no se declaran permisos Android sensibles ni `QUERY_ALL_PACKAGES`.
- [x] Dependencias actuales revisadas: no se añadieron SDK de anuncios ni analítica.
- [x] Política de privacidad de borrador y checklist de Play Console incluidos.
- [x] Workflow de GitHub Actions incluido para compilar APK debug y AAB release sin firma.
- [ ] Compilación real con Android Gradle Plugin.
- [ ] Instalación y pruebas en dispositivos físicos/emuladores.
- [ ] AAB firmado con la clave privada del desarrollador.
- [ ] URL pública de privacidad y contacto de soporte del desarrollador.
- [ ] Ficha, declaraciones y revisión final en Play Console.

No se pudo ejecutar la compilación local: este entorno no contiene Android SDK ni Gradle y no tiene resolución de red para instalar esas herramientas. El AAB release producido por el workflow no estará firmado; la firma de publicación debe configurarse de forma privada por el desarrollador.
